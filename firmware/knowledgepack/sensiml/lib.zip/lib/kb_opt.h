#ifndef __KB_OPT_H__
#define __KB_OPT_H__

#include <stdint.h>
#include <limits.h>
#ifdef OPT_ARM_M4_DSP
#if defined(__GNUC__)
#include "cmsis_gcc.h"
#elif defined(__ARMCC_VERSION) && (__ARMCC_VERSION > 400677)
#include "cmsis_armcc.h"
#endif
#include "arm_math.h"
#endif

#include "kbutils.h"

// clang-format off
#ifdef __cplusplus
extern "C"
{
    #endif

    void lsup_distance(uint8_t *pSrcA, uint8_t *pSrcB, uint8_t *pDist, uint8_t *pMaxDist, uint32_t blockSize);
    void l1_distance(uint8_t *pSrcA, uint8_t *pSrcB, uint32_t *pDist, uint32_t blockSize);
    void compute_distance_matrix(unsigned char *x, unsigned char *y, int x_size, int y_size, uint8_t num_channels);
    int compute_warping_distance(int x_size, int y_size);
    int get_distance_matrix_value(int i, int j);
    int get_globdist(int i, int j);


    #ifdef __cplusplus
}
#endif
// clang-format on

#endif //__KB_OPT_H__
