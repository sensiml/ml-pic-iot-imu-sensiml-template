//############################################################################
// SENSIML CONFIDENTIAL                                                          #
//                                                                               #
// Copyright (c) 2022 SensiML Corporation.                                       #
//                                                                               #
// The source code contained or  described  herein and all documents related     #
// to the  source  code ("Material")  are  owned by SensiML Corporation or its   #
// suppliers or licensors. Title to the Material remains with SensiML Corpora-   #
// tion  or  its  suppliers  and  licensors. The Material may contain trade      #
// secrets and proprietary and confidential information of SensiML Corporation   #
// and its suppliers and licensors, and is protected by worldwide copyright      #
// and trade secret laws and treaty provisions. No part of the Material may      #
// be used,  copied,  reproduced,  modified,  published,  uploaded,  posted,     #
// transmitted, distributed,  or disclosed in any way without SensiML's prior    #
// express written permission.                                                   #
//                                                                               #
// No license under any patent,copyright, trade secret or other intellectual     #
// property  right  is  granted  to  or  conferred upon you by disclosure or     #
// delivery of the Materials, either expressly, by implication,  inducement,     #
// estoppel or otherwise.Any license under such intellectual property rights     #
// must be express and approved by SensiML in writing.                           #
//                                                                               #
// Unless otherwise agreed by SensiML in writing, you may not remove or alter    #
// this notice or any other notice embedded in Materials by SensiML or SensiML's #
// suppliers or licensors in any way.                                            #
//                                                                               #
//################################################################################

#ifndef KBUTILS_H
#define KBUTILS_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <limits.h>

#include <math.h>
#define MODF modff
#define SQRT(x) sqrt((float)x)
#define ABS(x) fabs(x)
#define POW(x, y) pow((float)x, (float)y)
#define ROUND(x) (int)(x + 0.5f)
#define sign(d) ((d) < 0 ? -1 : ((d) > (0)))
#include "string.h"

#include "stdint.h"
#include "stdlib.h"
#include "kb_typedefs.h"
#include "kb_common.h"
#include "rb.h"

#define max(a, b) \
	({ __typeof__ (a) _a = (a); \
       __typeof__ (b) _b = (b); \
     _a > _b ? _a : _b; })

#define fabs(x) ((x) >= 0 ? (x) : (-(x)))

#define roundoff(x) (int)(x + 0.5f)
#define LOG10(x) log10(x)

#ifndef INT_MIN
#define INT_MIN 0x80000000
#endif
#ifndef INT_MAX
#define INT_MAX 0x7FFFFFFF
#endif
#ifndef KB_SHORT_INT_MIN
#define KB_SHORT_INT_MIN SHRT_MIN
#endif
#ifndef KB_SHORT_INT_MAX
#define KB_SHORT_INT_MAX SHRT_MAX
#endif

enum convops
{
	OP_ABS_SUM = 0, // Compute absolute value of the area
	OP_SUM_ABS		// Compute sum of absolute values of area
};

struct minmax
{
	uint16_t index;
	float min;
	float max;
};

typedef enum _FGFunctionName_
{
	global_p2p_high_frequency_name = 0,
	global_p2p_low_frequency_name,
	max_p2p_half_high_frequency_name,
	absolute_area_high_frequency_name,
	absolute_area_low_frequency_name,
	total_area_low_frequency_name,
	total_area_high_frequency_name
} FGFunctionName;

// Modes
enum convmode
{
	MOD_RAW = 0, // MOD_RAW - No conversion will be done to the raw data before applying the operation
	MOD_LF,		 // MOD_LF - Data will be transformed to the moving average before applying the operation
	MOD_HF		 // MOD_HF - Data will have the moving average subtracted before applying the operation
};

#define FLOAT_MAX 3.3928236692093846346337460743177e+38f
#define FLOAT_MIN 5.8774717541114375398436826861112e-39f

#define KB_FLT_MAX (FLOAT)0x7f7fffff
#define KB_FLT_MIN -(KB_FLT_MAX)

#ifndef SMOOTHING_FACTOR
#define SMOOTHING_FACTOR 50
#endif
#ifndef PI
#define PI 3.1415926f
#endif
#ifndef FFT_N
#define FFT_N 128
#endif

// Pre allocated data structures that are used by sub functions
extern int sorted_data_len;
extern int feature_selection[];
extern SENSOR_DATA_T sortedData[];

// clang-format off

#ifdef __cplusplus
extern "C"
{
#endif

int tr_sensor_sensors(SENSOR_DATA_T *rawdata, int *cols_to_use, int num_cols, SENSOR_DATA_T *frameData);

FLOAT calc_area(ringb *pringb, int col, int nframes, FLOAT sample_rate, int smoothing_factor, int mode, int op);
int max_min_high_low_freq(ringb *pringb, int base_index, int nframes, int col, int offset, int sf, int lowhigh, FLOAT *max, FLOAT *min);
void column_to_row_complex(ringb *pringb, int col, int nframes, struct compx *cmpxData, int complen);
FLOAT crossing_rate(ringb *pringb, int base_index, int nframes, FLOAT threshold);
FLOAT crossing_rate_over_zero(ringb *pringb, int base_index, int nframes);
FLOAT crossing_rate_over_sum(ringb *pringb, int base_index, int nframes, int sum);
int number_of_crossings_over_threshold(ringb *rb, int base_index, int num_rows, int threshold);
int number_of_positive_crossings_over_threshold(ringb *rb, int base_index, int num_rows, int threshold);
int number_of_negative_crossings_over_threshold(ringb *rb, int base_index, int num_rows, int threshold);
int number_of_crossings_over_threshold_regions(ringb *rb, int base_index, int num_rows, int positive_threshold, int negative_threshold);
int number_of_positive_crossings_over_threshold_regions(ringb *rb, int base_index, int num_rows, int positive_threshold, int negative_threshold);
int number_of_negative_crossings_over_threshold_regions(ringb *rb, int base_index, int num_rows, int positive_threshold, int negative_threshold);

void sortarray(SENSOR_DATA_T *a, int len);
SENSOR_DATA_T *sorted_copy(ringb *pringb, int base_index, int len, int force_sort);
FLOAT kb_std(ringb *pringb, int base_index, int datalen);
FLOAT mean(ringb *pringb, int base_index, int datalen);
FLOAT stat_moment(ringb *pringb, int base_index, int datalen, int moment);
FLOAT sum(ringb *pringb, int base_index, int datalen);

//INT returns
int i_mean(ringb *pringb, int base_index, int datalen);

//BUFFER FUNCTIONS
FLOAT buffer_mean(ringb *pringb, int base_index, int offset, int datalen);
FLOAT buffer_standard_deviation(ringb *pringb, int base_index, int offset, int nrows);
FLOAT buffer_variance(ringb *pringb, int base_index, int offset, int nrows);
FLOAT buffer_cumulative_sum(ringb *pringb, int base_index, int offset, int datalen);
FLOAT buffer_absolute_mean(ringb *pringb, int base_index, int offset, int datalen);
FLOAT buffer_absolute_cumulative_sum(ringb *pringb, int base_index, int offset, int datalen);
FLOAT buffer_median(ringb *pringb, int index, int datalen);
int16_t buffer_min(ringb *pringb, int base_index, int offset, int datalen);
int16_t buffer_max(ringb *pringb, int base_index, int offset, int datalen);
int buffer_min_max(ringb *pringb, int base_index, int nrows, int offset, int *min, int *max);
int buffer_argmax(ringb *pringb, int base_index, int datalen);
void buffer_autoscale(ringb *pringb, int base_index, int length);


//ARRAY FUNCTIONS
void remove_mean_data_float(FLOAT *pdata, int len);
void autoscale_data_float(FLOAT *pdata, int len);
void apply_hanning_float(FLOAT *pdata, int len);
void remove_mean_data_int(int16_t *pdata, int len);
void autoscale_data_int(int16_t *pdata, int len);
void apply_hanning_int(int16_t *pdata, int len);
void array_max_uint8(uint8_t *pSrc, uint32_t blockSize, uint8_t *pResult);

//FEATURE SELECTION FUNCTIONS
bool selection_contains(int feature, int num_feature_selection, int *feature_selection);
int selection_index(int feature, int num_feature_selection, int *feature_selection);

FLOAT stats_percentile_presorted(const SENSOR_DATA_T *input_data, int nframes, FLOAT pct);

void saveSensorData(ringb *pringb, SENSOR_DATA_T *rawdata, int count);

int MA_Symmetric(ringb *pringb, int base_index, int nFrameLen, int nWinSize, int nColToUse, int nSampleRate,
					int nFlagDC_AC, int nFlagUseSampleRate, int nABSBeforSum, int nABSAfterSum, int nFGName, FLOAT *pFV);

int ratio_diff_impl(ringb *pringb, int base_index, int nlen, int window_size, int flag_h_l, float *out);

//OTHER UTILITY FUNCTIONS
uint16_t bitwise_absolute_value(int16_t x);

#ifdef __cplusplus
}
// clang-format on
#endif
#endif
