/* ----------------------------------------------------------------------
 * Copyright (c) 2022 SensiML Corporation
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * ---------------------------------------------------------------------- */

#include "kb_pipeline.h"

#include "pme.h"

#include "sml_profile_utils.h"
static unsigned int profile_cycle_count = 0;
static float profile_total_time = 0.0f;
static float profile_avg_iter_time = 0.0f;

#pragma GCC diagnostic ignored "-Wunused-function"
#pragma GCC diagnostic ignored "-Wunused-variable"

// Operations
#define FLT_MAX (FLOAT) 0x7f7fffff
#define FLT_MIN -(FLT_MAX)
#define NUMBER_OF_SENSORS 3
#define MAX_FEATURE_SELECTION 0

int          columns[NUMBER_OF_SENSORS];
int          feature_selection[MAX_FEATURE_SELECTION];
int          num_feature_selection = 0;
static float params[6];


int KB_data_streaming_TestModel(void* model, SENSOR_DATA_T *pSample)
{
	int FrameIdx = 0;
	kb_model_t * kb_model = (kb_model_t*)model;

	columns[0] = ACCELEROMETERX_S_TestModel;
	columns[1] = ACCELEROMETERY_S_TestModel;
	columns[2] = ACCELEROMETERZ_S_TestModel;
	FrameIdx += tr_sensor_sensors(pSample, columns, 3, &kb_model->frameData[FrameIdx]);	
saveSensorData(kb_model->pringb, kb_model->frameData, kb_model->framelen);
	return 1;
}



int KB_data_segmentation_TestModel(void* model, int model_index)
{
	int FrameIdx = 0;
	kb_model_t * kb_model = (kb_model_t*)model+model_index;
	int new_samples = rb_num_items(kb_model->pringb, kb_model->last_read_idx);
	int i;
	for (i=0; i<new_samples; i++){
			kb_model->last_read_idx += 1;
		
	if(tr_windowing(kb_model, columns, 0, kb_model->psegParams)){
			return 1;
		}
	}
	// Colect more samples
	return -1;
}



int KB_feature_gen_model_TestModel(void * model, int *nfeats)
{
	int column = 0;
	int num_params = 1;
	kb_model_t * kb_model = (kb_model_t*)model;
	int nframes = kb_model->sg_length;
	int CompIdx = (kb_model->feature_bank_index) * (kb_model->feature_bank_size);
	
num_params = 0;	
columns[0] = ACCELEROMETERX_D_TestModel;	
*nfeats = fg_stats_mean(kb_model, columns, 1, params, num_params, &kb_model->pFeatures[CompIdx]);	
CompIdx += *nfeats;	
num_params = 0;	
columns[0] = ACCELEROMETERY_D_TestModel;	
*nfeats = fg_stats_mean(kb_model, columns, 1, params, num_params, &kb_model->pFeatures[CompIdx]);	
CompIdx += *nfeats;	
num_params = 0;	
columns[0] = ACCELEROMETERZ_D_TestModel;	
*nfeats = fg_stats_mean(kb_model, columns, 1, params, num_params, &kb_model->pFeatures[CompIdx]);	
CompIdx += *nfeats;	
num_params = 0;	
columns[0] = ACCELEROMETERX_D_TestModel;	
*nfeats = fg_stats_stdev(kb_model, columns, 1, params, num_params, &kb_model->pFeatures[CompIdx]);	
CompIdx += *nfeats;	
num_params = 0;	
columns[0] = ACCELEROMETERY_D_TestModel;	
*nfeats = fg_stats_stdev(kb_model, columns, 1, params, num_params, &kb_model->pFeatures[CompIdx]);	
CompIdx += *nfeats;	
num_params = 0;	
columns[0] = ACCELEROMETERZ_D_TestModel;	
*nfeats = fg_stats_stdev(kb_model, columns, 1, params, num_params, &kb_model->pFeatures[CompIdx]);	
CompIdx += *nfeats;	
return 1;
}



int KB_feature_transform_TestModel(void * model)
{
	kb_model_t * kb_model = (kb_model_t*)model;
	
	static struct minmax aminmax[6] = {
	
		{0, -2277.355f, 825.035f},	
		{1, -4128.655f, 2300.045f},	
		{2, 114.78f, 4119.075f},	
		{3, 5.898251f, 1724.9673f},	
		{4, 10.810439f, 4096.9956f},	
		{5, 12.103279f, 1802.7498f},	
	};
	
	int start = (kb_model->feature_bank_index+1) * (kb_model->feature_bank_size);
	
	int total_features = (kb_model->feature_bank_size) * (kb_model->feature_bank_number);
	
	min_max_scale(kb_model->pFeatures, kb_model->feature_vector, kb_model->feature_vector_size, start, total_features, 0, 255, aminmax);
	return 1;

}



int KB_recognize_vector_TestModel(void * model)
{
	int ret;
	kb_model_t * kb_model = (kb_model_t*)model;
	ret = pme_simple_submit_pattern(kb_model->classifier_id , kb_model->feature_vector);
	return ret;

}

