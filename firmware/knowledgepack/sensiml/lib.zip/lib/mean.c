/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "kbutils.h"

//      mean.c
//
//	Return the arithmetic mean of the elements in an array.
//
//      This is the integer optimized version of mean.c
//      It calls the inline routine get_axis_data(), which returns an int16.
//      The input data values are therefore in -32k..32k (16 bits).
//      The routine get_axis_data() is in ../include/rb.h.
//
//	Note that there is a small danger of integer overflow if more than
//	64k data elements are input.
//
//	Note that we are now supporting both FLOAT and int32 return values.
//	Note that we lose a small amount of  precision when the int32 divide
//	takes place, at the end of the function.

FLOAT mean(ringb *pringb, int base_index, int len)
{
    if ((!pringb) || (!len))
    {
        return 0;
    }

    int irow;
    int64_t sum = 0;

    for (irow = 0; irow < len; irow++)
    {
        sum += get_axis_data(pringb, base_index + irow);
    }

    return ((FLOAT)sum / len);
}

int i_mean(ringb *pringb, int base_index, int len)
{
    int irow;
    int64_t sum;

    sum = 0;

    for (irow = 0; irow < len; irow++)
    {
        sum += get_axis_data(pringb, base_index + irow); // add int16 to int32
    }

    return (int)(sum / len);
}
