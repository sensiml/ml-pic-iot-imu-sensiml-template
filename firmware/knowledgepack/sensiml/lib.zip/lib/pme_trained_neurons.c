#include "pme_trained_neurons.h"

static qm_pme_neuron_vector_t kb_neuron_vectors_0[MAX_NUM_NEURONS_0] = 
{
	{.vector={144, 126, 245, 1, 1, 1}},
	{.vector={152, 18, 58, 120, 188, 138}},
	{.vector={102, 216, 210, 232, 59, 193}},
	{.vector={227, 1, 0, 58, 49, 81}},
	{.vector={252, 15, 97, 84, 102, 122}},
	{.vector={246, 10, 82, 56, 48, 105}},
	{.vector={252, 11, 72, 204, 255, 255}},
};
qm_pme_neuron_attribute_t kb_neuron_attribs_0[MAX_NUM_NEURONS_0] = 
{
	{ .influence=400, .category=4 },
	{ .influence=280, .category=2 },
	{ .influence=400, .category=3 },
	{ .influence=137, .category=1 },
	{ .influence=125, .category=2 },
	{ .influence=400, .category=1 },
	{ .influence=400, .category=2 },
};
kb_classifier_row_t kb_classifier_rows[1] = {
	

	{
		.classifier_id=0,
		.num_patterns=NUM_NEURONS_0,
		.pattern_size=6,
		.max_patterns=MAX_NUM_NEURONS_0,
		.num_classes=NUM_CLASSES_0,
		.num_channels=1,
		.classifier_mode=KB_CLASSIFICATION_RBF,
		.norm_mode=KB_DISTANCE_L1,
		.stored_patterns=kb_neuron_vectors_0,
		.stored_attribs=kb_neuron_attribs_0,
	},
};

const int neurons_count = KB_TOTAL_NUMBER_OF_NEURONS;
