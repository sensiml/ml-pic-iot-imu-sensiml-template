/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include <limits.h>

/* kb_classifier includes */
#include "kb_pipeline.h"
#include "kb_common.h"
#include "kb_classifier.h"
#include "pme.h"
#include "pme_trained_neurons.h"
#include "kb.h"
#include "kb_defines.h"

#define STARTER_EDITION_CHECK 0
#define MAX_RINGBUFFERS_USED 3

#define NUMBER_OF_PARENT_MODELS 1
#define NUMBER_OF_MODELS 1
#define NUMBER_OF_SEGMENTERS 1
#define NUMBER_OF_FEATURE_BANKS_0 1
#define NUMBER_OF_FEATURES_PER_BANK_0 6
#define TOTAL_FEATURES_0 6
#define NUMBER_OF_RINGBUFFS_0 3
#define _RAWDATABUF_LEN_0 768
#define NUMBER_OF_SBUFFS_0 0
#define _RAWDATASBUF_LEN_0 0
static int rbuffers_len[NUMBER_OF_PARENT_MODELS] = {3};
static int sbuffers_len[NUMBER_OF_PARENT_MODELS] = {0};
static FVCOMP_T pFeatures_TestModel[TOTAL_FEATURES_0];
static uint8_t feature_vector_TestModel[FEATURE_VECTOR_SIZE_0];
static uint8_t model_uuid_TestModel[16] = {0x16,0x8e,0xeb,0xbb,0x0,0x89,0x48,0x17,0x8c,0x3a,0xed,0xf2,0xa7,0x8a,0xb7,0xa6};
static SENSOR_DATA_T frameData_0[NUMBER_OF_RINGBUFFS_0];
SENSOR_DATA_T KBSensorData_0[_RAWDATABUF_LEN_0];
ring_buffer_t rbuffers_0[NUMBER_OF_RINGBUFFS_0];
SENSOR_DATA_T SSensorData_0[_RAWDATASBUF_LEN_0];
ring_buffer_t sbuffers_0[NUMBER_OF_SBUFFS_0];
static SENSOR_DATA_T *frameData[NUMBER_OF_PARENT_MODELS] = {frameData_0};
static FVCOMP_T *pFeatures[NUMBER_OF_MODELS] = {pFeatures_TestModel};
uint8_t *pfeature_vectors[NUMBER_OF_MODELS] = {feature_vector_TestModel};
SENSOR_DATA_T *KBSensorData[NUMBER_OF_PARENT_MODELS] = {KBSensorData_0};
ring_buffer_t *rbuffers[NUMBER_OF_PARENT_MODELS] = {rbuffers_0};
SENSOR_DATA_T *SSensorData[NUMBER_OF_PARENT_MODELS] = {SSensorData_0};
ring_buffer_t *sbuffers[NUMBER_OF_PARENT_MODELS] = {sbuffers_0};


#define SORTED_DATA_LEN 0
SENSOR_DATA_T sortedData[SORTED_DATA_LEN];
#ifndef SORTED_DATA_LEN
#define SORTED_DATA_LEN 8192
SENSOR_DATA_T sortedData[SORTED_DATA_LEN];
#endif

static uint8_t feature_vector[MAX_VECTOR_SIZE];
static seg_params segParams[NUMBER_OF_SEGMENTERS];
static kb_model_t kb_models[NUMBER_OF_MODELS];
static bool reset_num_classes = true;

// need to do some checking on this
#if SML_DEBUG
#define PRINTBUFFLEN 256 + 4 * MAX_VECTOR_SIZE
static char printfbuff[PRINTBUFFLEN];
static char *pbuf = printfbuff;

#endif
static SENSOR_DATA_T segment_sample_data[MAX_RINGBUFFERS_USED];

#if STARTER_EDITION_CHECK

static bool kb_check_starter_still_has_classifications(int model_index)
{
    if (kb_models[model_index].total_classifications > max_classifications[model_index])
    {
        dbgprintlev(1, "Community Edition classification limit reached.\n");
        return false;
    }
    return true;
}
#endif

void ring_buffer_init()
{
    int cbuflen, ibuf, imodel, sbuflen;
    static int init_framelen = 1;

    if (init_framelen)
    {
        init_framelen = 0;
        for (imodel = 0; imodel < NUMBER_OF_PARENT_MODELS; imodel++)
        {
            // Initialize the ring buffers (this will have to be more carefully done)
            switch (imodel)
            {
                case(0):
		cbuflen = _RAWDATABUF_LEN_0 / NUMBER_OF_RINGBUFFS_0;
sbuflen = 0;
break;
                //FILL_SRING_BUFFER_INIT_SIZES
            }
            for (ibuf = 0; ibuf < rbuffers_len[imodel]; ibuf++)
            {
                setup_rb(&rbuffers[imodel][ibuf], (int16_t *)&KBSensorData[imodel][ibuf * cbuflen], cbuflen);
            }

            for (ibuf = 0; ibuf < sbuffers_len[imodel]; ibuf++) // Make this a fill
            {
                setup_rb(&sbuffers[imodel][ibuf], (int16_t *)&SSensorData[imodel][ibuf * sbuflen], sbuflen);
            }
        }
    }
    return;
}

void kb_model_init()
{
    segParams[0].window_size = 200;
segParams[0].delta = 200;

    kb_models[0].psegParams = &segParams[0];
kb_models[0].feature_bank_filled_flag = false;
kb_models[0].sg_length = 0;
kb_models[0].sg_index = 0;
kb_models[0].last_read_idx = 0;
kb_models[0].pFeatures = pFeatures[0];
kb_models[0].feature_bank_index = 0;
kb_models[0].streaming_filter_length = 1;
kb_models[0].feature_bank_number = NUMBER_OF_FEATURE_BANKS_0;
kb_models[0].feature_bank_size = NUMBER_OF_FEATURES_PER_BANK_0;
kb_models[0].feature_vector_size = FEATURE_VECTOR_SIZE_0;
kb_models[0].feature_vector = pfeature_vectors[0];
kb_models[0].m_profile.enabled = 0;
kb_models[0].classifier_id = 0;
kb_models[0].classifier_type = 1;
kb_models[0].pringb = rbuffers[0];
kb_models[0].psringb = sbuffers[0];
kb_models[0].frameData = frameData[0];
kb_models[0].parent = 0;
kb_models[0].framelen = NUMBER_OF_RINGBUFFS_0;
kb_models[0].sframelen = NUMBER_OF_SBUFFS_0;
kb_models[0].feature_gen = KB_feature_gen_model_TestModel;
kb_models[0].data_streaming = KB_data_streaming_TestModel;
kb_models[0].segmentation = KB_data_segmentation_TestModel;
kb_models[0].recognize_vector = KB_recognize_vector_TestModel;
kb_models[0].feature_transform = KB_feature_transform_TestModel;
kb_models[0].model_uuid = model_uuid_TestModel;
if(reset_num_classes){

kb_models[0].total_classifications = 0;
reset_num_classes = false;
}

    ring_buffer_init();

    	pme_simple_init(kb_classifier_rows, KB_NUM_PME_CLASSIFIERS);

}

int kb_flush_model_buffer(int model_index)
{
    int parent = kb_models[model_index].parent;
    ringb *rb;

    for (int i = 0; i < kb_models[parent].framelen; i++)
    {
        rb = &(kb_models[parent].pringb[i]);
        rb_reset(rb);
    }

    for (int i = 0; i < kb_models[parent].sframelen; i++)
    {
        rb = &(kb_models[parent].psringb[i]);
        rb_reset(rb);
    }

    kb_models[model_index].sg_length = 0;
    kb_models[model_index].sg_index = 0;
    kb_models[model_index].last_read_idx = 0;
    kb_models[model_index].feature_bank_index = 0;

    return 1;
}

int kb_flush_model(int model_index)
{
    int ret = 1;
    switch (kb_models[model_index].classifier_type)
    {
    	case(1):
		pme_flush_model(kb_models[model_index].classifier_id);
		break;

    default:
        ret = 0;
    }
    return ret;
}

void kb_data_streaming_reset(int model_index)
{
    switch(model_index)
{
case(0):
tr_windowing_init(&kb_models[model_index], kb_models[model_index].psegParams);
break;
}
    rb_unlock(kb_models[model_index].pringb);
}

int kb_reset_model(int model_index)
{
    kb_data_streaming_reset(model_index);

    return 1;
}

void kb_reset_feature_banks(int model_index)
{
    kb_models[model_index].feature_bank_index = 0;
    kb_models[model_index].feature_bank_filled_flag = false;
}

bool kb_feature_bank_ready(int model_index)
{
    return kb_models[model_index].feature_bank_filled_flag;
}

void kb_feature_generation_reset(int model_index)
{
    int start = kb_models[model_index].feature_bank_size * kb_models[model_index].feature_bank_index;
    for (int i = 0; i < kb_models[model_index].feature_bank_size; i++)
    {
        kb_models[model_index].pFeatures[start + i] = 0.0f;
    }
    sorted_copy(kb_models[model_index].pringb, 0, 0, 1);
}

void kb_feature_generation_increment(int model_index)
{
    kb_models[model_index].feature_bank_index += 1;

    if (kb_models[model_index].feature_bank_index == kb_models[model_index].feature_bank_number-1)
    {
    kb_models[model_index].feature_bank_filled_flag =true;
    }

    if (kb_models[model_index].feature_bank_index >= kb_models[model_index].feature_bank_number)
    {
        kb_models[model_index].feature_bank_index = 0;
    }
}

uint16_t kb_recognize(int model_index)
{
    int ret;
#if STARTER_EDITION_CHECK
    if (kb_check_starter_still_has_classifications(model_index) == false)
    {
        return USHRT_MAX - 1;
    }
    kb_models[model_index].total_classifications++;
#endif
    ret = kb_models[model_index].recognize_vector(&kb_models[model_index]);
    return (uint16_t)ret;
}

uint16_t kb_feature_transform(int model_index)
{
    int ret;

    ret = kb_models[model_index].feature_transform(&kb_models[model_index]);

    return (uint16_t)ret;
}

int kb_feature_generation(int model_index)
{
    int ret = -1;
    int nfeats = 0;

    ret = kb_models[model_index].feature_gen(&kb_models[model_index], &nfeats);
    switch (ret)
    {
    case 1:
        break;
    case -1:
        dbgprintlev(1, "Segment was filtered.");
        break;

    default:
        dbgprintlev(1, "Unknown return from feature generation.");
    }
    return ret;
}

int kb_data_streaming(SENSOR_DATA_T *pSample, int nsensors, int model_index)
{
    int ret = 0;

    ret = kb_models[model_index].data_streaming(&kb_models[model_index], pSample);

    return ret;
}

int kb_segmentation(int model_index)
{
    int ret = 0;

    ret = kb_models[model_index].segmentation(&kb_models, model_index);

    if (ret == 1)
    {
        rb_lock(kb_models[model_index].pringb);
    }

    return ret;
}

void kb_generate_children_features(int model_index)
{
    if (model_index != kb_models[model_index].parent)
    {
        return;
    }

    for (int index = 0; index < NUMBER_OF_MODELS; index++)
    {
        if (kb_models[index].parent == model_index && index != model_index)
        {
            if (kb_segmentation(index) == 1)
            {
                kb_feature_generation_reset(index);
                kb_feature_generation(index);
                kb_feature_generation_increment(index);
            }
        }
    }
}

int kb_generate_classification(int model_index)
{
    int ret = -1;
    if (kb_feature_transform(model_index) == 1)
    {
        ret = kb_recognize(model_index);
        if (ret == USHRT_MAX)
        {
            ret = 0;
        }
    }

    return ret;
}

int kb_run_model(SENSOR_DATA_T *pSample, int nsensors, int model_index)
{
    int ret = -1;
    if (kb_data_streaming(pSample, nsensors, model_index))
    {
        if (kb_segmentation(model_index) == 1)
        {
            kb_feature_generation_reset(model_index);
            if (kb_feature_generation(model_index) == 1)
            {
                ret = kb_generate_classification(model_index);
                kb_feature_generation_increment(model_index);
                return ret;
            }
            else
            {
                kb_reset_feature_banks(model_index);
                kb_reset_model(model_index);
                return -2;
            }
        }
    }
    return -1;
}

int kb_run_model_with_cascade_features(SENSOR_DATA_T *pSample, int nsensors, int model_index)
{
    int ret = -1;
    if (kb_data_streaming(pSample, nsensors, model_index))
    {
        if (kb_segmentation(model_index) == 1)
        {
            kb_feature_generation_reset(model_index);
            if (kb_feature_generation(model_index) == 1)
            {
                if (kb_feature_bank_ready(model_index))
                {
                    ret = kb_generate_classification(model_index);
                    kb_generate_children_features(model_index);
                    kb_feature_generation_increment(model_index);
                }
                else
                {
                    ret = -2;
                    kb_generate_children_features(model_index);
                    kb_feature_generation_increment(model_index);
                    kb_reset_model(model_index);
                }

                return ret;
            }
            else
            {
                kb_reset_feature_banks(model_index);
                kb_reset_model(model_index);
                return -2;
            }
        }
    }
    return -1;
}

int kb_run_model_with_cascade_reset(SENSOR_DATA_T *pSample, int nsensors, int model_index)
{
    int ret = -1;

    if (kb_data_streaming(pSample, nsensors, model_index))
    {
        if (kb_segmentation(model_index) == 1)
        {
            kb_feature_generation_reset(model_index);
            if (kb_feature_generation(model_index) == 1)
            {

                if (kb_models[model_index].feature_bank_index == kb_models[model_index].feature_bank_number - 1)
                {
                    ret = kb_generate_classification(model_index);
                    kb_generate_children_features(model_index);
                    kb_reset_feature_banks(model_index);
                    return ret;
                }
                else
                {
                    kb_feature_generation_increment(model_index);
                    kb_generate_children_features(model_index);
                    kb_data_streaming_reset(model_index);
                    return -2;
                }
            }
            else
            {
                kb_reset_feature_banks(model_index);
                kb_reset_model(model_index);
                return -2;
            }
        }
    }
    return -1;
}

void kb_add_segment(uint16_t *pBuffer, int len, int nbuffs, int model_index)
{
    int ibuf;
    for (ibuf = 0; ibuf < nbuffs; ibuf++)
    {
        setup_rb_with_data(&kb_models[model_index].pringb[ibuf], (int16_t *)&pBuffer[ibuf * len], next_pow_2(len), len);
        kb_models[model_index].sg_length = 0;
        kb_models[model_index].sg_index = 0;
        kb_models[model_index].last_read_idx = 0;
    }
}

int kb_run_segment(int model_index)
{
    int ret;
    if (kb_segmentation(model_index) == 1)
    {
        kb_feature_generation_reset(model_index);
        ret = kb_feature_generation(model_index);
        if (ret ==1)
        {
            ret = kb_generate_classification(model_index);
            kb_feature_generation_increment(model_index);
            return ret;
        }

    }
    return -1;
}

int kb_run_segment_with_cascade_features(int model_index)
{
    int ret = -1;
    if (kb_segmentation(model_index) == 1)
    {
        kb_feature_generation_reset(model_index);
        if (kb_feature_generation(model_index) == 1)
        {
            ret = kb_generate_classification(model_index);
            kb_feature_generation_increment(model_index);
            return ret;
        }
        else
        {
            kb_feature_generation_increment(model_index);
            kb_data_streaming_reset(model_index);
            kb_generate_children_features(model_index);
            return -2;
        }
    }

    return -1;
}

int kb_run_segment_with_cascade_reset(int model_index)
{
    int ret = -1;
    if (kb_segmentation(model_index) == 1)
    {
        kb_feature_generation_reset(model_index);
        if (kb_feature_generation(model_index) == 1)
        {
            if (kb_models[model_index].feature_bank_index == kb_models[model_index].feature_bank_number - 1)
            {

                ret = kb_generate_classification(model_index);
                kb_generate_children_features(model_index);
                kb_reset_feature_banks(model_index);
                return ret;
            }
            else
            {
                kb_feature_generation_increment(model_index);
                kb_data_streaming_reset(model_index);
                kb_generate_children_features(model_index);
                return -2;
            }
        }
    }
    return -1;
}

int kb_add_last_pattern_to_model(int model_index, uint16_t category, uint16_t influence)
{
    // This needs to be added in a way so that if a classifier doesn't support it, it just returns false. ie no training of random forest on the device
    int ret = 1;

    switch (model_index)
    {
    	case(0):
		ret = pme_add_new_pattern(kb_models[model_index].classifier_id, kb_models[model_index].feature_vector, category, influence);
		break;

    default:
        ret = 0;
        break;
    }
    return ret;
}

int kb_add_custom_pattern_to_model(int model_index, uint8_t *feature_vector, uint16_t category, uint16_t influence)
{
    int ret = 1;
    switch (model_index)
    {
    	case(0):
		ret = pme_add_new_pattern(kb_models[model_index].classifier_id, feature_vector, category, influence);
		break;

    default:
        ret = 0;
        break;
    }

    return ret;
}

int kb_score_model(int model_index, uint16_t category)
{
    int ret = 1;
    switch (model_index)
    {
    	case(0):
		ret = 0;
		break;

    default:
        ret = 0;
        break;
    }
    return ret;
}

int kb_retrain_model(int model_index)
{
    int ret = 1;
    switch (model_index)
    {
    	case(0):
		ret = 0;
		break;

    default:
        ret = 0;
        break;
    }

    return ret;
}

int kb_get_model_header(int model_index, void *model_header)
{
    int ret = 1;
    pme_model_header_t *pme_model_header = (pme_model_header_t *)model_header;
    switch (kb_models[model_index].classifier_type)
    {
        	case(1):
		pme_model_header->number_patterns = pme_get_number_patterns(kb_models[model_index].classifier_id);
pme_model_header->pattern_length = kb_models[model_index].feature_vector_size;
		break;

        ret = 0;
        break;
    }
    return ret;
}

int kb_get_model_pattern(int model_index, int pattern_index, void *pattern)
{
    int ret = 1;
    pme_pattern_t *pme_pattern = (pme_pattern_t *)pattern;
    switch (kb_models[model_index].classifier_type)
    {
    	case(1):
		pme_return_pattern(model_index, pattern_index, pme_pattern);
		break;

    default:
        ret = 0;
        break;
    }
    return ret;
}

const uint8_t *kb_get_model_uuid_ptr(int model_index)
{
    if (model_index < NUMBER_OF_MODELS)
    {
        return (const uint8_t *)kb_models[model_index].model_uuid;
    }
    else
    {
        return NULL;
    }
}

int kb_get_feature_vector_size(int model_index)
{
    return kb_models[model_index].feature_vector_size;
}

void kb_get_feature_vector_v2(int model_index, uint8_t *fv_arr)
{
    for (int i = 0; i < kb_models[model_index].feature_vector_size; i++)
    {
        fv_arr[i] = kb_models[model_index].feature_vector[i];
    }
}

void kb_get_feature_vector(int model_index, uint8_t *fv_arr, uint8_t *p_fv_len)
{
    int i;
    for (i = 0; i < kb_models[model_index].feature_vector_size; i++)
    {
        fv_arr[i] = kb_models[model_index].feature_vector[i];
    }
    *p_fv_len = kb_models[model_index].feature_vector_size;
}

void sml_get_segment_length(int model_index, int *p_seg_len)
{
    *p_seg_len = kb_models[model_index].sg_length * kb_models[model_index].feature_bank_number * kb_models[model_index].streaming_filter_length;
}

void sml_get_feature_bank_number(int model_index, int *p_feature_bank_number)
{
    *p_feature_bank_number = kb_models[model_index].feature_bank_number;
}

int kb_get_segment_length(int model_index)
{
    return kb_models[model_index].sg_length * kb_models[model_index].feature_bank_number * kb_models[model_index].streaming_filter_length;
}

void kb_get_segment_data(int model_index, int number_samples, int index, SENSOR_DATA_T *p_sample_data)
{
    for (int i = index; i < index + number_samples; i++)
    {
        for (int col = 0; col < kb_models[model_index].framelen; col++)
        {
            p_sample_data[i] = get_axis_data(kb_models[model_index].pringb + col, i);
        };
    };
}

int kb_set_feature_vector(int model_index, uint8_t *feature_vector)
{
    int i;

    for (i = 0; i < kb_models[model_index].feature_vector_size; i++)
    {
        kb_models[model_index].feature_vector[i] = feature_vector[i];
    };

    return i;
}

int kb_recognize_feature_vector(int model_index)
{
    return (int)kb_recognize(model_index);
}

int kb_get_classification_result_info(int model_index, void *model_results)
{
    int ret = 1;
    switch (kb_models[model_index].classifier_type)
    {
        	case(1):
		ret = 0;
		break;


    default:
        ret = 0;
        break;
    }

    return ret;
}

int kb_print_model_score(int model_index)
{
    int ret = 1;
    switch (kb_models[model_index].classifier_type)
    {
    	case(0):
		ret = 0;
		break;

    default:
        ret = 0;
        break;
    }
    return ret;
}

int kb_get_segment_start(int model_index)
{
    return kb_models[model_index].sg_index * kb_models[model_index].streaming_filter_length;
}

bool kb_is_profiling_enabled(int model_index)
{
    return kb_models[model_index].m_profile.enabled;
}

void kb_get_feature_gen_times(int model_index, float *time_arr)
{
    if (!kb_models[model_index].m_profile.enabled)
    {
        return;
    }
    for (int i = 0; i < kb_models[model_index].feature_vector_size; i++)
    {
        time_arr[i] = kb_models[model_index].m_profile.feature_gen_times[i];
    }
}

void kb_get_feature_gen_cycles(int model_index, unsigned int *cycle_arr)
{
    if (!kb_models[model_index].m_profile.enabled)
    {
        return;
    }
    for (int i = 0; i < kb_models[model_index].feature_vector_size; i++)
    {
        cycle_arr[i] = kb_models[model_index].m_profile.feature_gen_cycles[i];
    }
}

float kb_get_classifier_time(int model_index)
{
    if (!kb_models[model_index].m_profile.enabled)
    {
        return -1.0f;
    }
    return kb_models[model_index].m_profile.classifier_time;
}

unsigned int kb_get_classifier_cycles(int model_index)
{
    if (!kb_models[model_index].m_profile.enabled)
    {
        return 0;
    }
    return kb_models[model_index].m_profile.classifier_cycles;
}
