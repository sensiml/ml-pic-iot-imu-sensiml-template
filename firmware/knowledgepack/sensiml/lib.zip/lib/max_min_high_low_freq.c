/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "kbutils.h"

/*
* max_min_high_low_freq - compute the maximum and minimum of the high or low frequency
*							 component of a waveform.
*
* Inputs
*		nframes - number of rows in the array
*       col - which column to analyze
* 		offset - offset into the column to start
*		sf	- smoothing factor (how many data points on either side of a sample to use to
*				compute the mean.)
*		max = pointer to FLOAT to receive the maximum value.
*		min = pointer to FLOAT to receive the minimum value.
*		lowhigh  - 1 = use high-freq values, 0 = use low freq values.
*/
int max_min_high_low_freq(ringb *pringb, int base_index, int nframes, int col, int offset, int sf, int lowhigh, FLOAT *max, FLOAT *min)
{
	int i;
	FLOAT dsum;
	FLOAT davg;
	FLOAT dmin = KB_FLT_MAX;
	FLOAT dmax = KB_FLT_MIN;
	FLOAT dval;
	FLOAT dval0 = (FLOAT)get_axis_data(pringb + col, base_index + offset);

	// Compute the running mean for the first sample
	for (i = -sf / 2, dsum = 0.0; i < sf / 2; i++)
	{
		if (i < 0)
		{
			dsum += dval0; // pad with first value on left side.
		}
		else
		{
			dsum += (FLOAT)get_axis_data(pringb + col, base_index + i + offset);
		}
	}
	davg = dsum / sf;

	// Subtract the mean from the first sample
	dval = dval0 - davg;

	// Compare to max/min
	if (dval < dmin)
		dmin = dval;
	if (dval > dmax)
		dmax = dval;

	// Compute the running mean for the each sample
	for (i = 1; i < nframes; i++)
	{
		int decndx = i - sf / 2;
		int addndx = i + sf / 2;
		int dec = decndx < 0 ? dval0 : get_axis_data(pringb + col, base_index + decndx + offset);
		int add = addndx >= nframes ? get_axis_data(pringb + col, base_index + nframes + offset - 1) : get_axis_data(pringb + col, base_index + addndx + offset);

		dsum = dsum - dec + add;
		davg = dsum / sf;

		switch (lowhigh)
		{
		case MOD_HF: // Subtract the mean to get the high freq components.
			dval = get_axis_data(pringb + col, base_index + i + offset) - davg;
			break;

		case MOD_LF:
			dval = davg; // Return the mean for the low freq components.
			break;

		case MOD_RAW:
			dval = get_axis_data(pringb + col, base_index + i + offset);
			break;
		}
		if (dval < dmin)
			dmin = dval;
		if (dval > dmax)
			dmax = dval;
	}
	*max = dmax;
	*min = dmin;

	return 1;
}
