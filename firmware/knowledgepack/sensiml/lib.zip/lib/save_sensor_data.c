/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "rb.h"
#include "kbutils.h"
/*!
* \brief Save raw sensor data into KBSensorData in s16 format.
*
* \param rawdata Raw sensor data array pointer.
* \param count Count of data values to save into the KBSensorData array.
*/
void saveSensorData(ringb *pringb, SENSOR_DATA_T *rawdata, int count)
{
    int i;

    for (i = 0; i < count; i++)
    {
        rb_add(pringb + i, *rawdata++);
    }

    return;
}

/*!
* \brief Save raw sensor data into KBSensorData in s16 format.
*
* \param rawdata Mixed size sensor data array.
* \param row startcol in rows to the frame to update.
* \param count Count of data values to save into the KBSensorData array.
*/
void saveSenseDataOffset(ringb *pringb, SENSOR_DATA_T *rawdata, int startcol, int count)
{
    int icol;

    for (icol = startcol; icol < (count + startcol); icol++)
    {
        rb_add(pringb + icol, *rawdata++);
    }
    return;
}
