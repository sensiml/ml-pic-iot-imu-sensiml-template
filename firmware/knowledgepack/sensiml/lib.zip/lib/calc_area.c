/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "rb.h"
#include "kbutils.h"

#define MIN(x, y) (x < y ? x : y)

/*
* calc_area - compute various areas of a waveform
*
* Inputs
*       col - which column to analyze
*		nrows - number of rows in the array
*       sample_rate - samples/sec.
*		smoothing factor (how many data points on either side of a sample to use to compute the mean.)
*		mode - conversion to perform on raw data values before the operation is performed
*			 0 = raw data
*			 1 = Low frequency
*			 2 = high frequency
*		op - operation to perform on converted data
*
* Output : FLOAT resultant value.
*
* The moving average for the signal is computed by starting with the average of
* the first sample, over 'smoothing_factor' samples on either side of the sample.
* The samples to the left of the first sample are assumed to be identical to the
* first sample. Likewise, for samples to the right of the last sample.
* Once this is done the average for each successive sample is computed as follows:
* Sum = Sum - 1st sample in the last sum + sample following the last summed value
* Avg = Sum/(smoothing factor + 1)
* This is repeated for each sample.
* This method avoids creating temporary arrays to hold the intermediate averages.
*/
FLOAT calc_area(ringb *pringb, int col, int nrows, FLOAT sample_rate, int smoothing_factor, int mode, int op)
{
	int irow;
	FLOAT dsum = 0.0, asum = 0.0;
	FLOAT darea = 0.0;
	FLOAT davg = 0.0;
	FLOAT dval = 0.0;	// Data value
	int base_index = 0; // REPLACE THIS WITH AN INPUT WHEN THIS FUNCTION IS READY

	// Process the samples
	for (irow = 0; irow < nrows; irow++)
	{
		int icnt;

		asum = 0.0;
		for (icnt = 0; icnt < smoothing_factor; icnt++)
		{
			if (icnt + irow < nrows)
				asum += (FLOAT)get_axis_data(pringb + col, base_index + icnt + irow);
		}
		davg = asum / MIN(smoothing_factor, nrows - irow);
		dval = (FLOAT)get_axis_data(pringb + col, base_index + irow);

		if (mode == MOD_HF) // Use high-frequency components
		{
			dval -= davg; // Subtract the mean to get the high freq components.
		}
		else
		{
			dval = davg; // Use the mean for the low freq components.
		}

		// Perform the operation on the remaining 'modified' samples
		if (op == OP_ABS_SUM)
			dsum += dval / sample_rate;
		else if (op == OP_SUM_ABS)
			dsum += (dval < 0 ? -dval : dval) / sample_rate;
	}
	darea = dsum;
	if (op == OP_ABS_SUM)
	{
		if (dsum < 0.0)
			darea = -dsum;
	}
	return darea;
}
