/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "kbutils.h"

//      This routine computes the nth moment of a given data set.
//      There are pretty much two optimizations:  First, we use a case
//      statement instead of using the POW library function.
//      Second, we do the calculations using int32 or int64 instead
//      of float.
//      As customay, we supply three entry points:
//      i_stat_moment()         returns an integer.
//      f_stat_moment()         returns a float.
//      stat_moment()           compatible with the old calling style
//
//      Note:  The i_stat_moment() will generally produce different results
//      than the other routines, because it uses a fixed-point value for the
//      average (and the interior summations).  This is generally a small error.
//
//      Note:  There will be an integer overflow in cases where more than
//      128 million 12-bit data points are fed into this routine.
//      We know that this won't happen in the current version,
//      but be careful in the future. . .

FLOAT f_stat_moment(ringb *rb, int base_index, int len, int moment)
//
//      The floating-point version, cleaned up somewhat by not
//      using the POW library routine in every case.
//
{
	int i;
	int stop;
	FLOAT avg;
	FLOAT temp;
	FLOAT sum;

	if (len <= 0)
		return 0.0;

	switch (moment)
	{
	case 1:
		return 0.0;
		break;
	case 2:
		avg = mean(rb, base_index, len);
		sum = 0.0f;
		stop = base_index + len;

		for (i = base_index; i < stop; i++)
		{
			temp = (FLOAT)(get_axis_data(rb, i)) - avg;
			sum += temp * temp; // temp**2
		}
		return sum / len;
		break;
	case 3:
		avg = mean(rb, base_index, len);
		sum = 0.0f;
		stop = base_index + len;

		for (i = base_index; i < stop; i++)
		{
			temp = (FLOAT)(get_axis_data(rb, i)) - avg;
			sum += temp * temp * temp; // temp**3
		}
		return sum / len;
		break;
	default:
		avg = mean(rb, base_index, len);
		sum = 0.0f;
		stop = base_index + len;

		for (i = base_index; i < stop; i++)
		{
			sum +=
				(float)POW((float)get_axis_data(rb, i) -
							   avg,
						   (float)moment);
		}
		return sum / len;
		break;
	}
}

int32_t i_stat_moment(ringb *rb, int base_index, int len, int moment)
//
//      The integer version.
//
//      Note that, for moments other than 2 or 3, it just returns 0.
//      Typical higher-order moment results won't fit in 32 bits.
//
{
	int i;
	int stop;
	int32_t avg;
	int32_t temp;
	int64_t sum;

	if (len <= 0)
		return 0;

	switch (moment)
	{
	default:
	case 1:
		return 0;
		break;
	case 2:
		sum = 0;
		avg = (int32_t)mean(rb, base_index, len);
		stop = base_index + len;

		for (i = base_index; i < stop; i++)
		{
			temp = get_axis_data(rb, i) - avg;
			sum += (temp * temp); // temp**2
		}
		return (int32_t)(sum / len);
		break;
	case 3:
		sum = 0;
		avg = (int32_t)mean(rb, base_index, len);
		stop = base_index + len;

		for (i = base_index; i < stop; i++)
		{
			temp = get_axis_data(rb, i) - avg;
			sum += ((int64_t)(temp * temp)) * temp; // temp**3
		}
		return (int32_t)(sum / len);
		break;
	}
}

FLOAT stat_moment(ringb *rb, int base_index, int len, int moment)
//
//      The generic version, used for compatibility.
//      Calls f_stat_moment(), at this time.
//
{
	return f_stat_moment(rb, base_index, len, moment);
}

//
