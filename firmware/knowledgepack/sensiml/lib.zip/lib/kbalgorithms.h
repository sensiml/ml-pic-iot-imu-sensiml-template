/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#ifndef _KB_ALGORITHMS_H_
#define _KB_ALGORITHMS_H_

#include "kb_common.h"
#include "kbutils.h"

/* kb_model_t is a data structure that contains all of the information about a pipeline. The parts relevant to kbalgorithms are:

kb_model->pringb: This is the pointer to the first ring buffer
kb_model->framelen: This is the number of ring buffer columns for the pipeline
kb_model->sg_index: This is the position of the start of the index in the pringbuffer
kb_model->sg_length: This is the length of an identified segment of data.
kb_model->pFeatures: The pointer to the feature vector
kb_model->feature_vector_size: The size of the feature vector
kb_model->framedata: The most current sample of data after sensor transforms have been applied
kb_model->pSegParams: Pointer to the segmenter parameter data structure
*/

// clang-format off


#ifdef __cplusplus
extern "C"
{
#endif

/*STREAMING SENSOR TRANSFORMS
Expected behavior
1. Takes on frame of sample(s) at a time and pointer to the streaming ring buffer
2. perfroms some operation which requires time lagging the signal
3. replaces transforms the data in the frame of samples
4. returns 1, or -1 if the sbuffer needs more data before performing the transform

Note: At the moment these must be applied to all columns
*/

int streaming_moving_average(ring_buffer_t *pringb, SENSOR_DATA_T *pSample, int *cols_to_use, int num_cols, int filter_order);
int streaming_downsample_by_averaging(ring_buffer_t *pringb, SENSOR_DATA_T *pSample, int *cols_to_use, int num_cols, int filter_length);
int streaming_downsample_by_decimation(ring_buffer_t *pringb, SENSOR_DATA_T *pSample, int *cols_to_use, int num_cols, int filter_length);
int streaming_high_pass_filter(ring_buffer_t *pringb, SENSOR_DATA_T *pSample, int *cols_to_use, int num_cols, float alpha);

/*SENSOR TRANSFORMS
Expected behavior
1. Takes one frame of sample(s) at a time and a pointer to the end of the FrameIDX array.
2. performs an operation such as magnitude and stores it into the FrameIDX array
3. Returns the number of points added to FrameIDX array

The frameData contains the data that will eventually be added to the ring buffer
*/

int tr_sensor_magnitude(SENSOR_DATA_T *rawdata, int *cols_to_use, int num_cols, SENSOR_DATA_T *frameData);
int st_sensor_abs_average(SENSOR_DATA_T *rawdata, int *cols_to_use, int num_cols, SENSOR_DATA_T *frameData);
int st_sensor_average(SENSOR_DATA_T *rawdata, int *cols_to_use, int num_cols, SENSOR_DATA_T *frameData);

/*SEGEMENTERS
1. Returns 1 if a segment is found, otherwise returns 0.
2. Must have either window size or max buffer length defined as part of the algorithm.  This is used to define the buffer size of the circular buffer.
3. Must make use of the ring buffer without modification to input data or data inside of the ringbuffer.
4. All parameters must be passed through a struct seg_params.
5. All user facing parameters must be defined defined in the python input contract with a corresponding c_param:index.
6. All flags must be part of seg_params as multiple segmenter can use the same segmenter.
7. The start of the segment is added to kb_model->sg_index
8. The length of the segment is added to kb_model->sg_length
9. On segment found, lock the ring buffer
10. Must have an init function which describes reset the ring buffer after a segment has been found.
*/

int windowing_threshold_segmenter(kb_model_t *kb_model, int *columns, int num_cols, seg_params *segParams);
void windowing_threshold_segmenter_init(kb_model_t *kb_model, seg_params *segParams);
int tr_windowing(kb_model_t *model, int *columns, int num_cols, seg_params *segParams);
void tr_windowing_init(kb_model_t *model, seg_params *segParams);
int p2p_threshold(kb_model_t *kb_model, int *columns, int num_cols, seg_params *segParams);
void p2p_threshold_init(kb_model_t *kb_model, seg_params *segParams);
int max_min_threshold_segmenter(kb_model_t *kb_model, int *columns, int num_cols, seg_params *segParams);
void max_min_threshold_segmenter_init(kb_model_t *kb_model, seg_params *segParams);
int general_threshold_segmenter(kb_model_t *kb_model, int *columns, int num_cols, seg_params *segParams);
void general_threshold_segmenter_init(kb_model_t *kb_model, seg_params *segParams);
int double_peak_key_segmenter(kb_model_t *kb_model, int *columns, int num_cols, seg_params *segParams);
void double_peak_key_segmenter_init(kb_model_t *kb_model, seg_params *segParams);
int sg_cascade_windowing(kb_model_t *model, int *columns, int num_cols, seg_params *segParams);
void sg_cascade_windowing_init(kb_model_t *model, seg_params *segParams);

/*SEGMENT FILTERS

Expected Behavior
1. Returns 1 or 0. 1 if we the pipeline should continue, 0 if the pipeline should be terminated for this segment.
(note this can potentially cause issues where data is modified more than once in the case of a sliding window)
*/

int sg_filter_mse(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int sg_filter_threshold(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int sg_filter_energy_threshold(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);

/*SEGMENT TRANSFORMS

Expected Behavior
1. Operates only on a single segment of data. Starting at position kb_model->sg_index to a length of kb_model->sg_length.
3. Can modify data in the ring buffer, but is not allowed to add new data to the ring buffer.
(note this can potentially cause issues where data is modified more than once in the case of a sliding window)
*/

int tr_segment_scale_factor(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int tr_segment_offset_factor(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int tr_segment_strip(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int tr_segment_pre_emphasis_filter(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int tr_segment_normalize(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int tr_segment_vertical_scale(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);
int tr_segment_horizontal_scale(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params);

/*FEATURE GENERATORS

Expected Behavior
1. Create a single or multiple features from a segment of data. Starting at position kb_model->sg_index to a length of kb_model->sg_length.
2. Adds a feature as a float to the feature vector.
3. Returns the number of features added to the feature vector.
*/

int fg_transpose_signal(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_interleave_signal(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_time_signal_duration(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_time_pct_time_over_zero(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_time_pct_time_over_sigma(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_time_pct_time_over_second_sigma(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_time_pct_time_over_threshold(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_time_abs_pct_time_over_threshold(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_time_avg_time_over_threshold(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_mean(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_zero_crossings(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_positive_zero_crossings(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_negative_zero_crossings(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_median(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_linear_regression(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_stdev(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_skewness(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_kurtosis(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_iqr(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_pct025(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_pct075(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_pct100(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_minimum(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_maximum(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_sum(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_abs_sum(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_abs_mean(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_stats_variance(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_amplitude_global_p2p_low_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_amplitude_global_p2p_high_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_amplitude_max_p2p_half_high_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_amplitude_peak_to_peak(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_amplitude_min_max_sum(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_shape_ratio_high_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_shape_difference_high_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_shape_median_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_shape_absolute_median_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_roc_mean_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_roc_mean_crossing_rate(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_roc_zero_crossing_rate(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_roc_sigma_crossing_rate(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_roc_second_sigma_crossing_rate(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_roc_threshold_crossing_rate(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_roc_threshold_with_offset_crossing_rate(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_physical_average_movement_intensity(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_physical_variance_movement_intensity(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_physical_average_signal_magnitude_area(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_mfcc(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_fixed_width_histogram(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_min_max_scaled_histogram(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_frequency_dominant_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_frequency_spectral_entropy(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_frequency_power_spectrum(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_energy_average_energy(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_energy_total_energy(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_energy_average_demeaned_energy(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_sampling_downsample(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_max_column(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_min_column(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_min_max_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_mean_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_p2p_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_abs_max_column(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_correlation(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_mean_crossing_rate(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_mean_crossing_rate_with_offset(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_median_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_cross_column_peak_location_difference(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_sampling_downsample_avg_with_normalization(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_sampling_downsample_max_with_normalization(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_area_total_area(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_area_absolute_area(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_area_total_area_low_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_area_absolute_area_low_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_area_total_area_high_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_area_absolute_area_high_frequency(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_area_power_spectrum_density(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);
int fg_frequency_peak_frequencies(kb_model_t *kb_model, int *cols_to_use, int num_cols, FLOAT *params, int num_params, FLOAT *pFV);




/*FEATURE VECTOR TRANSFORM

Expected Behavior
1. Takes a pointer to the feature generator and feature params.
2. Operates on the feature vectors in place
*/

int min_max_scale(FVCOMP_T *pFeatures, uint8_t *feature_vector, int nfeats, int start, int total_features, FLOAT minbound, FLOAT maxbound, struct minmax *m);
int normalize(FLOAT *pFV, int numComps);
int quantize_254(FLOAT *pFV, int ncomps);

#ifdef __cplusplus
}
#endif
// clang-format on

#endif //_KB_ALGORITHMS_H_
