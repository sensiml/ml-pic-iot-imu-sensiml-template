/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "kbutils.h"

static int MA_Symmetric_mm(ringb *pringb, int base_index, int nFrameLen,
						   int nWinSize, int nColToUse, int nSampleRate,
						   int isAC, int nFlagUseSampleRate,
						   int nABSBeforSum, int nABSAfterSum, int nFGName,
						   FLOAT *pFV)
//
//      The version of Moving Average Symmetric which does minimum/maximum code.
//      Anything having to do with sum code is ignored.
//
{
	ringb *rb = pringb + nColToUse; // pointer to ring buffer

	int32_t latest_dc_sum = 0;		// sum of the sample values for the set of window size
	int32_t sum_dc_sum = 0;			// sum of all DC mean values;
	int32_t max_dc_sum, min_dc_sum; // latest max and min of sum for DC mean

	int32_t latest_ac_sum = 0;
	int32_t sum_ac_sum = 0;			// sum of all AC mean values;
	int32_t max_ac_sum, min_ac_sum; // latest max and min of sum of AC mean

	int half_win_size_offset = nWinSize >> 1; // divided by 2

	float max = -FLOAT_MAX, min = FLOAT_MAX; // max and min of mean values

	int i; // loop index variable

	// Calculate sum of sample values of the first window
	for (i = 0; i < nWinSize; i++)
	{
		latest_dc_sum += rb_read(rb, i + base_index);
	}

	// update statistical variables for the window
	max_dc_sum = min_dc_sum = latest_dc_sum;
	sum_dc_sum += nABSBeforSum == 1 ? fabs(latest_dc_sum) : latest_dc_sum;

	if (isAC != 0)
	{
		// Chris pointed out that it should be the mid sample of the window
		latest_ac_sum =
			(rb_read(rb, half_win_size_offset + base_index) * nWinSize) -
			latest_dc_sum;

		max_ac_sum = min_ac_sum = latest_ac_sum;
		sum_ac_sum +=
			nABSBeforSum == 1 ? fabs(latest_ac_sum) : latest_ac_sum;
	}
	// Bug fix to JSD-7213 by adding +1 to this loop
	for (i = 1; i < nFrameLen - nWinSize + 1; i++)
	{

		latest_dc_sum =
			latest_dc_sum - rb_read(rb, i - 1 + base_index) + rb_read(rb, i + nWinSize - 1 + base_index);
		sum_dc_sum +=
			nABSBeforSum == 1 ? fabs(latest_dc_sum) : latest_dc_sum;

		if (max_dc_sum < latest_dc_sum)
		{
			max_dc_sum = latest_dc_sum;
		}
		else if (min_dc_sum > latest_dc_sum)
		{
			min_dc_sum = latest_dc_sum;
		}

		if (isAC != 0)
		{
			// Chris pointed out that it should be the mid sample of the window
			latest_ac_sum =
				(rb_read(rb, i + half_win_size_offset + base_index) *
				 nWinSize) -
				latest_dc_sum;

			if (max_ac_sum < latest_ac_sum)
			{
				max_ac_sum = latest_ac_sum;
			}
			else if (min_ac_sum > latest_ac_sum)
			{
				min_ac_sum = latest_ac_sum;
			}
		}
	}

	if (isAC != 0)
	{
		max = (max_ac_sum * 1.0) / nWinSize; // AC
		min = (min_ac_sum * 1.0) / nWinSize;
	}
	else
	{
		max = (max_dc_sum * 1.0) / nWinSize; // DC
		min = (min_dc_sum * 1.0) / nWinSize;
	}

	switch (nFGName)
	{
	case global_p2p_high_frequency_name:
		*pFV = max - min;
		break;
	case global_p2p_low_frequency_name:
		*pFV = max - min;
		break;
	case max_p2p_half_high_frequency_name:
		*pFV = max - min;
		break;
	case absolute_area_high_frequency_name:
	case absolute_area_low_frequency_name:
	case total_area_low_frequency_name:
	case total_area_high_frequency_name:
	default:
		pFV[0] = 1234.5678; // error flag value
		break;
	}

	return 1;
}

static int MA_Symmetric_sum(ringb *pringb, int base_index, int nFrameLen,
							int nWinSize, int nColToUse, int nSampleRate,
							int isAC, int nFlagUseSampleRate,
							int nABSBeforSum, int nABSAfterSum,
							int nFGName, FLOAT *pFV)
//
//      The version of Moving Average Symmetric which does summation code.
//      Anything having to do with minimum/maximum code is ignored.
//
{
	ringb *rb = pringb + nColToUse; // pointer to ring buffer

	int32_t latest_dc_sum = 0; // sum of the sample values for the set of window size
	int32_t sum_dc_sum = 0;	   // sum of all DC mean values;

	int32_t latest_ac_sum = 0;
	int32_t sum_ac_sum = 0; // sum of all AC mean values;

	int half_win_size_offset = nWinSize >> 1; // divided by 2

	float sum_fv = 0; // sum of feature values,i.e, sum of each mean values

	float fSampleInterval =
		nFlagUseSampleRate == 1 ? (1.0f / (float)nSampleRate) : 1.0f;

	int i; // loop index variable

	// Calculate sum of sample values of the first window
	for (i = 0; i < nWinSize; i++)
	{
		latest_dc_sum += rb_read(rb, i + base_index);
	}

	// update statistical variables for the window
	sum_dc_sum += nABSBeforSum == 1 ? fabs(latest_dc_sum) : latest_dc_sum;

	if (isAC != 0)
	{
		// Chris pointed out that it should be the mid sample of the window
		latest_ac_sum =
			(rb_read(rb, half_win_size_offset + base_index) * nWinSize) -
			latest_dc_sum;

		sum_ac_sum +=
			nABSBeforSum == 1 ? fabs(latest_ac_sum) : latest_ac_sum;
	}
	// Bug fix to JSD-7213 by adding +1 to this loop
	for (i = 1; i < nFrameLen - nWinSize + 1; i++)
	{

		latest_dc_sum =
			latest_dc_sum - rb_read(rb, i - 1 + base_index) + rb_read(rb, i + nWinSize - 1 + base_index);
		sum_dc_sum +=
			nABSBeforSum == 1 ? fabs(latest_dc_sum) : latest_dc_sum;

		if (isAC != 0)
		{
			// Chris pointed out that it should be the mid sample of the window
			latest_ac_sum =
				(rb_read(rb, i + half_win_size_offset + base_index) *
				 nWinSize) -
				latest_dc_sum;

			sum_ac_sum +=
				nABSBeforSum == 1 ? fabs(latest_ac_sum) : latest_ac_sum;
		}
	}

	if (isAC != 0)
	{
		sum_fv = (sum_ac_sum * fSampleInterval) / nWinSize; // AC
	}
	else
	{
		sum_fv = (sum_dc_sum * fSampleInterval) / nWinSize; // DC
	}

	sum_fv = nABSAfterSum == 1 ? fabs(sum_fv) : sum_fv;

	switch (nFGName)
	{
	case absolute_area_high_frequency_name:
		*pFV = sum_fv;
		break;
	case absolute_area_low_frequency_name:
		*pFV = sum_fv;
		break;
	case total_area_low_frequency_name:
		*pFV = fabs(sum_fv);
		break;
	case total_area_high_frequency_name:
		*pFV = sum_fv;
		break;
	default:
	case global_p2p_high_frequency_name:
	case global_p2p_low_frequency_name:
	case max_p2p_half_high_frequency_name:
		pFV[0] = 1234.5678; // error flag value
		break;
	}

	return 1;
}

int MA_Symmetric(ringb *pringb, int base_index, int nFrameLen,
				 int nWinSize, int nColToUse, int nSampleRate, int isAC,
				 int nFlagUseSampleRate, int nABSBeforSum,
				 int nABSAfterSum, int nFGName, FLOAT *pFV)
{
	nWinSize = nWinSize * 2 + 1;

	switch (nFGName)
	{
	case global_p2p_high_frequency_name:
	case global_p2p_low_frequency_name:
	case max_p2p_half_high_frequency_name:
		MA_Symmetric_mm(pringb, base_index, nFrameLen,
						nWinSize, nColToUse, nSampleRate, isAC,
						nFlagUseSampleRate, nABSBeforSum,
						nABSAfterSum, nFGName, pFV);
		break;

	case absolute_area_high_frequency_name:
	case absolute_area_low_frequency_name:
	case total_area_low_frequency_name:
	case total_area_high_frequency_name:
		MA_Symmetric_sum(pringb, base_index, nFrameLen,
						 nWinSize, nColToUse, nSampleRate, isAC,
						 nFlagUseSampleRate, nABSBeforSum,
						 nABSAfterSum, nFGName, pFV);
		break;
	default:
		pFV[0] = 1234.5678; // error flag value
		break;
	}

	return 1;
}

//
