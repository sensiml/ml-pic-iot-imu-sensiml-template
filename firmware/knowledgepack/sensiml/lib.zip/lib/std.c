/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "kbutils.h"

//      std.c
//
//      Return square root of the arithmetic mean of the square of the
//      elements in an array.  It is called the "root mean square",
//      or the Standard Deviation.
//
//      std = SQRT(mean(abs(x - x.mean())**2))
//
//      This is the integer optimized version of std.c
//      It calls the inline routine get_axis_data(), which returns an int16.
//      The input data values are therefore in -32k..32k (16 bits).
//      The routine get_axis_data() is in ../include/rb.h.
//
//      Note that there is a small danger of integer overflow if more than
//      64k data elements are input.
//
//      Note that we are now supporting both FLOAT and int32 return values.
//      Note that we lose a small amount of  precision when the int32 divide
//      takes place, at the end of the function.

int i_mean(ringb *pringb, int base_index, int len);

FLOAT f_std(ringb *pringb, int base_index, int len)
{
    int irow;
    FLOAT sum = 0.0;
    FLOAT tmp;
    FLOAT xmean;

    // Compute the mean of the input data
    xmean = mean(pringb, base_index, len);

    for (irow = 0; irow < len; irow++)
    {
        tmp = get_axis_data(pringb, base_index + irow) - xmean;
        sum += tmp * tmp;
    }

    return SQRT(sum / len);
}

int32_t i_std(ringb *pringb, int base_index, int len)
//
//      Returns the standard deviation, as computed using integers.
//
{
    int irow;
    int32_t tmp;
    int32_t xmean;
    int64_t sum = 0.0;

    // Compute the mean of the input data
    xmean = i_mean(pringb, base_index, len);

    for (irow = 0; irow < len; irow++)
    {
        tmp = get_axis_data(pringb, irow + base_index) - xmean;
        sum += tmp * tmp; // don't need 64-bit multiply
    }

    return (int32_t)(SQRT((FLOAT)sum / (FLOAT)len));
}

FLOAT kb_std(ringb *pringb, int base_index, int len)
//
//      Generic version, for compatibility
//
{
    return f_std(pringb, base_index, len);
}
