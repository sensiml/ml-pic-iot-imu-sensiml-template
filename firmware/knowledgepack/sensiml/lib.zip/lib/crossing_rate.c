/* ----------------------------------------------------------------------
* Copyright (c) 2022 SensiML Corporation
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*
* 1. Redistributions of source code must retain the above copyright notice,
*    this list of conditions and the following disclaimer.
*
* 2. Redistributions in binary form must reproduce the above copyright notice,
*    this list of conditions and the following disclaimer in the documentation
*    and/or other materials provided with the distribution.
*
* 3. Neither the name of the copyright holder nor the names of its contributors
*    may be used to endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
* LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
* CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
* OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
* ---------------------------------------------------------------------- */

#include "kbutils.h"
/*
 * crossing_rate
 *    Original version in KB transcode
 */
FLOAT crossing_rate(ringb *rb, int base_index, int num_rows, FLOAT threshold)
{
	int ncrossings = 0;
	int first;

	int irow;
	first = get_axis_data(rb, base_index + 0) - threshold;

	for (irow = 1; irow < num_rows; irow++)
	{
		int second = get_axis_data(rb, base_index + irow) - threshold;

		if (second == 0)
			continue;
		if (first * second < 0)
		{
			ncrossings++;
		}

		first = second;
	}

	float f = (FLOAT)ncrossings / num_rows;

	if (!num_rows)
		return 0.0f;
	else
		return f;
}

/*
 * crossing_rate_over_zero
 *    Added for zero crossing optimization
 */
FLOAT crossing_rate_over_zero(ringb *rb, int base_index, int num_rows)
{
	// return right away if num_rows is 0
	if (!num_rows)
	{
		// should print out error: unexpected num_rows = 0 here!

		return 0.0f;
	}

	int ncrossings = 0;
	short first;  // short is 16-bit signed
	short second; // short is 16-bit signed
	int irow;

	first = get_axis_data(rb, base_index + 0);

	for (irow = 1; irow < num_rows; irow++)
	{
		second = get_axis_data(rb, base_index + irow);

		if (second == 0)
			continue;
		if (((first & 0x8000) ^ (second & 0x8000)) == 0x8000)
		{
			ncrossings++;
		}

		first = second;
	}

	return ((FLOAT)ncrossings / num_rows);
}

/*
 * crossing_rate_over_sum
 *    Added for mean crossing optimization
 */
FLOAT crossing_rate_over_sum(ringb *rb, int base_index, int num_rows, int sum)
{
#if SML_DEBUG
	// return right away if num_rows is 0
	if (!num_rows)
	{
		// should print out error: unexpected num_rows = 0 here!
		return 0.0f;
	}
#endif //SML_DEBUG

	int ncrossings = 0;
	int32_t first;	// must be 32-bit int for bit mask operations
	int32_t second; // must be 32-bit int for bit mask operations
	int irow;

	first = (get_axis_data(rb, base_index) * num_rows) - sum;

	for (irow = 1; irow < num_rows; irow++)
	{

		second = (get_axis_data(rb, base_index + irow) * num_rows) - sum;

		if (second == 0)
			continue;
		if (((first & 0x80000000) ^ (second & 0x80000000)) == 0x80000000)
		{
			ncrossings++;
		}

		first = second;
	}

	return ((FLOAT)ncrossings) / num_rows;
}

int number_of_crossings_over_threshold(ringb *rb, int base_index, int num_rows, int threshold)
{

	int ncrossings = 0;
	int32_t first;	// must be 32-bit int for bit mask operations
	int32_t second; // must be 32-bit int for bit mask operations
	int i;

	first = get_axis_data(rb, base_index) - threshold;

	int final_index = base_index + num_rows;
	for (i = base_index + 1; i < final_index; i++)
	{

		second = get_axis_data(rb, i) - threshold;

		if (((first & 0x80000000) ^ (second & 0x80000000)) == 0x80000000)
		{
			ncrossings++;
		}

		first = second;
	}

	return ncrossings;
}

int number_of_positive_crossings_over_threshold(ringb *rb, int base_index, int num_rows, int threshold)
{

	int ncrossings = 0;
	int32_t first;	// must be 32-bit int for bit mask operations
	int32_t second; // must be 32-bit int for bit mask operations
	int i;

	first = get_axis_data(rb, base_index) - threshold;

	int final_index = base_index + num_rows;
	for (i = base_index + 1; i < final_index; i++)
	{

		second = get_axis_data(rb, i) - threshold;

		if (((first & 0x80000000) ^ (second & 0x80000000)) == 0x80000000)
		{
			if (second > first)
			{
				ncrossings++;
			}
		}

		first = second;
	}

	return ncrossings;
}

int number_of_negative_crossings_over_threshold(ringb *rb, int base_index, int num_rows, int threshold)
{

	int ncrossings = 0;
	int32_t first;	// must be 32-bit int for bit mask operations
	int32_t second; // must be 32-bit int for bit mask operations
	int i;

	first = get_axis_data(rb, base_index) - threshold;
	int final_index = base_index + num_rows;
	for (i = base_index + 1; i < final_index; i++)
	{

		second = get_axis_data(rb, i) - threshold;

		if (((first & 0x80000000) ^ (second & 0x80000000)) == 0x80000000)
		{
			if (first > second)
			{

				ncrossings++;
			}
		}

		first = second;
	}

	return ncrossings;
}

int number_of_crossings_over_threshold_regions(ringb *rb, int base_index, int num_rows, int positive_threshold, int negative_threshold)
{

	int ncrossings = 0;
	int32_t first;	// must be 32-bit int for bit mask operations
	int32_t second; // must be 32-bit int for bit mask operations
	int i;

	first = get_axis_data(rb, base_index);

	int final_index = base_index + num_rows;

	for (i = base_index + 1; i < final_index; i++)
	{

		second = get_axis_data(rb, i);

		// Positive Threshold Value Crossing

		// Postive Crossing
		if ((first < positive_threshold) && (second > positive_threshold))
		{
			ncrossings++;
		}

		// Negative Crossing
		if ((first > positive_threshold) && (second < positive_threshold))
		{
			ncrossings++;
		}

		// Negative Threshold Value Crossing

		// Postive Crossing
		if ((first < negative_threshold) && (second > negative_threshold))
		{
			ncrossings++;
		}

		// Negative Crossing
		if ((first > negative_threshold) && (second < negative_threshold))
		{
			ncrossings++;
		}

		first = second;
	}

	return ncrossings;
}

int number_of_positive_crossings_over_threshold_regions(ringb *rb, int base_index, int num_rows, int positive_threshold, int negative_threshold)
{

	int ncrossings = 0;
	int32_t first;	// must be 32-bit int for bit mask operations
	int32_t second; // must be 32-bit int for bit mask operations
	int i;

	first = get_axis_data(rb, base_index);

	int final_index = base_index + num_rows;

	for (i = base_index + 1; i < final_index; i++)
	{

		second = get_axis_data(rb, i);
		// Positive Threshold Value Crossing

		// Postive Crossing
		if ((first < positive_threshold) && (second > positive_threshold))
		{
			ncrossings++;
		}

		// Negative Threshold Value Crossing

		// Postive Crossing
		if ((first < negative_threshold) && (second > negative_threshold))
		{
			ncrossings++;
		}

		first = second;
	}

	return ncrossings;
}

int number_of_negative_crossings_over_threshold_regions(ringb *rb, int base_index, int num_rows, int positive_threshold, int negative_threshold)
{

	int ncrossings = 0;
	int32_t first;	// must be 32-bit int for bit mask operations
	int32_t second; // must be 32-bit int for bit mask operations
	int i;

	first = get_axis_data(rb, base_index);

	int final_index = base_index + num_rows;
	for (i = base_index + 1; i < final_index; i++)
	{

		second = get_axis_data(rb, i);

		// Positive Threshold Value Crossing
		// Negative Crossing
		if ((first > positive_threshold) && (second < positive_threshold))
		{
			ncrossings++;
		}

		// Negative Threshold Value Crossing
		// Negative Crossing
		if ((first > negative_threshold) && (second < negative_threshold))
		{
			ncrossings++;
		}

		first = second;
	}

	return ncrossings;
}