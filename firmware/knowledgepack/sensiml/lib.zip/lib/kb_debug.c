#include "kb_debug.h"

int kb_print_model_result(
    int model_index, int result, char* pbuf, bool feature_vectors, uint8_t* fv_arr)
{
    uint16_t fv_len;
    int32_t  count = 0;

    count += sprintf(
        pbuf,
        "{\"ModelNumber\":%d,\"Classification\":%d,\"SegmentStart\":%d,\"SegmentLength\":%d",
        model_index,
        result,
        kb_get_segment_start(model_index),
        kb_get_segment_length(model_index));

    if (feature_vectors)
    {
        fv_len = kb_get_feature_vector_size(model_index);
        kb_get_feature_vector_v2(model_index, fv_arr);

        count += sprintf(pbuf + count, ",\"FeatureVectorLength\":%d, \"FeatureVector\":[", fv_len);

        for (int j = 0; j < fv_len - 1; j++)
        {
            count += sprintf(pbuf + count, "%d,", fv_arr[j]);
        }
        count += sprintf(pbuf + count, "%d]", fv_arr[fv_len - 1]);
    };

    count += sprintf(pbuf + count, "}\n");

    return count;
}

void kb_print_model_class_map(int model_index, char* output)
{
    printf("\n");
    switch (model_index)
    {
        	case(0):
		printf("{\"1\":\"0\",\"2\":\"1\",\"3\":\"2\",\"4\":\"4\",\"0\":\"Unknown\"}");
		if(output != NULL)
		{
		sprintf( output,"{\"1\":\"0\",\"2\":\"1\",\"3\":\"2\",\"4\":\"4\",\"0\":\"Unknown\"}");
		}
		break;

        default:
            break;
    }
}

void kb_print_model_map()
{
    printf("{\"NumModels\":1,\"0\":\"TestModel\"}");
    printf("\n");
}

int kb_print_model_cycles(
    int model_index, char* pbuf, unsigned int* cycles)
{
    uint16_t     fv_len;
    int32_t      count = 0;
    float        classifier_time;
    unsigned int classifier_cycles;

    if(!kb_is_profiling_enabled(model_index))
    {
        count += sprintf(pbuf, "Model %d does not have profiling enabled\r\n", model_index);
        return count;
    }

    count += sprintf(
        pbuf,
        "{\"ModelNumber\":%d,\"Type\":\"Cycles\"",
        model_index);

    fv_len = kb_get_feature_vector_size(model_index);
    kb_get_feature_gen_cycles(model_index, cycles);
    classifier_cycles = kb_get_classifier_cycles(model_index);

    count += sprintf(pbuf + count, ", \"FeatureCycles\":[");
    for (int j = 0; j < fv_len - 1; j++)
    {
        count += sprintf(pbuf + count, "%d,", cycles[j]);
    }
    count += sprintf(pbuf + count, "%d],", cycles[fv_len - 1]);

    count += sprintf(pbuf + count, "\"ClassifierCycles\": %d", classifier_cycles);
    count += sprintf(pbuf + count, "}\n");

    return count;
}

int kb_print_model_times(
    int model_index, char* pbuf, float* times)
{
    uint16_t     fv_len;
    int32_t      count = 0;
    float        classifier_time;
    unsigned int classifier_cycles;

    if(!kb_is_profiling_enabled(model_index))
    {
        count += sprintf(pbuf, "Model %d does not have profiling enabled\r\n", model_index);
        return count;
    }

    count += sprintf(
        pbuf,
        "{\"ModelNumber\":%d,\"Type\":\"Times\"",
        model_index
    );
    fv_len = kb_get_feature_vector_size(model_index);
    kb_get_feature_gen_times(model_index, times);
    classifier_time   = kb_get_classifier_time(model_index);

    count += sprintf(pbuf + count, ", \"FeatureTimes\":[");
    for (int j = 0; j < fv_len - 1; j++)
    {
        count += sprintf(pbuf + count, "%.9f,", times[j]);
    }
    count += sprintf(pbuf + count, "%.9f], ", times[fv_len - 1]);
    count += sprintf(pbuf + count, "\"ClassifierTime\": %.9f, ", classifier_time);
    count += sprintf(pbuf + count, "}\n");

    return count;
}
